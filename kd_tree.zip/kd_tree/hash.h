#pragma once
using namespace std;
#include "point.h"
#include <list>

#define SIZEE 101
#define PRIMEE 7 //31


class Most_br {
private:
	int size;
	string name;
	int index;

public:
	Most_br(int _size, string _name, int _index) :size(_size), name(_name), index(_index) {}

	int get_index() { return index; }
	int get_size() { return size; }
	string get_name() { return name; }

};


class pizeria_hash_table {

private:
	list<point> arr[SIZEE];

public:

	pizeria_hash_table() {}

	int hash_function(string key) {
		int sum = 0;
		for (int i = 0; i < key.size(); ++i) {
			sum += (key[i] * (int)pow(PRIMEE, i)) % SIZEE;
		}

		return sum % SIZEE;
	}

	void add_to_hash_table(point p1) {
		int index = hash_function(p1.get_main_branch_name());

		arr[index].push_back(p1);

	}

	void print(string s1) {

		int  index = hash_function(s1);

		cout << "__" << "'" << s1 << "'" << endl;

		list<point>::iterator itr;

		if (arr[index].size() > 1) {

			for (itr = ++arr[index].begin(); itr != arr[index].end(); ++itr) {
				cout << " |" << endl;
				cout << " *---> " << (*itr).get_name() << " (x:" << (*itr).get_x() << ",y:" << (*itr).get_y() << ")" << endl;
			}
			cout << "\n";
		}

	}


	void Most_brs(vector<string> s1) {

		vector<Most_br> member;
		for (int i = 0; i < s1.size(); ++i) {

			int index = hash_function(s1[i]);

			list<point>::iterator itr = arr[index].begin();

			Most_br m1(arr[index].size(), itr->get_name(), index);
			member.push_back(m1);
		}

		/////sort record
		for (int i = 0; i < member.size(); ++i) {
			for (int j = 0; j < member.size(); ++j) {
				if (member[i].get_size() < member[j].get_size()) {
					Most_br tmp = member[i];
					member[i] = member[j];
					member[j] = tmp;
				}
			}
		}

		int index = member[0].get_index();

		list<point>::iterator itr;

		Color(2);
		if (arr[index].size() >= 1) {

			cout << "__" << "'" << member[0].get_name() << "'" << endl;
			for (itr = ++arr[index].begin(); itr != arr[index].end(); ++itr) {
				cout << " |" << endl;
				cout << " *---> " << (*itr).get_name() << " (x:" << (*itr).get_x() << ",y:" << (*itr).get_y() << ")" << endl;
			}
			cout << "\n";
		}
		Color(7);
	}


	void delet_pizeria(point p1) {

		int index = hash_function(p1.get_main_branch_name());

		list<point>::iterator itr;
		for (itr = arr[index].begin(); itr != arr[index].end(); ++itr) {
			if (itr->get_x() == p1.get_x() && itr->get_y() == p1.get_y()) {

				break;
			}
		}

		arr[index].erase(itr);


	}

	void find_nearest_branch(point p1, string name) {

		int index = hash_function(name);

		point best_point = *(arr[index].begin());

		double best_distance = distance(p1, best_point);

		list<point>::iterator itr;
		double dis;
		for (itr = arr[index].begin(); itr != arr[index].end(); ++itr) {

			dis = distance(p1, *itr);

			if (dis <= best_distance) {
				best_distance = dis;

				best_point = *itr;
			}

		}

		Color(5);
		cout << "\n";
		cout << "_" << " name:" << best_point.get_name() <<
			"(x:" << best_point.get_x() << ",y:" << best_point.get_y() << ")" << endl;
		Color(7);
	}

private:
	double distance(point a1, point a2) {
		double result = pow(a1.get_x() - a2.get_x(), 2) + pow(a1.get_y() - a2.get_y(), 2);
		return result;
	}

};



class the_neighbourhood {
private:
	int x1, x2, y1, y2;
	string name;
public:
	the_neighbourhood(int _x1, int _x2, int _y1, int _y2, string _name) :x1(_x1), x2(_x2), y1(_y1), y2(_y2), name(_name) {}
	the_neighbourhood() {}

	string get_name() { return name; }
	int get_x1() { return x1; }
	int get_x2() { return x2; }
	int get_y1() { return y1; }
	int get_y2() { return y2; }
};

class neighbor_hash_table {
private:
	the_neighbourhood arr[SIZEE];

public:
	neighbor_hash_table() {};

	int hash_function(string key) {
		int sum = 0;
		for (int i = 0; i < key.size(); ++i) {
			sum += (key[i] * (int)pow(PRIMEE, i)) % SIZEE;
		}

		return sum % SIZEE;
	}

	void add_to_hash_table(the_neighbourhood n1) {
		int index = hash_function(n1.get_name());

		arr[index] = n1;
	}

	the_neighbourhood& find(string key) {
		int index = hash_function(key);

		return arr[index];

	}


};

