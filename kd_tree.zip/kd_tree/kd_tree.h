#pragma once
#include <iostream>
#include <vector>
#include "point.h"
#include "color.h"

static int max;

class node {
private:
	point p;
	node* left;
	node* right;

public:
	node(point _p) :p(_p) {
		left = NULL;
		right = NULL;
	}

	point get_point() { return p; }

	friend class kd_tree;

};


void sort_based_x_axis(vector<point>& points) {
	for (int i = 0; i < points.size(); ++i) {
		for (int j = i + 1; j < points.size(); ++j) {
			if (points[i].get_x() > points[j].get_x()) {
				point p1 = points[j];
				points[j] = points[i];
				points[i] = p1;
			}
		}
	}
}

void sort_based_y_axis(vector<point>& points) {
	for (int i = 0; i < points.size(); ++i) {
		for (int j = i + 1; j < points.size(); ++j) {
			if (points[i].get_y() > points[j].get_y()) {
				point p1 = points[j];
				points[j] = points[i];
				points[i] = p1;
			}
		}
	}
}



class kd_tree {
private:
	node* root;
public:
	kd_tree() :root(NULL) {}

private:
	node* build_kd_tree(vector<point> points, int depth) {

		if (points.empty()) {
			return NULL;
		}

		int axis = depth % 2;

		// x axis
		if (axis == 0) {
			sort_based_x_axis(points);
		}
		// y axis
		else {
			sort_based_y_axis(points);
		}

		int medain = points.size() / 2;

		node* new_node = new node(points[medain]);

		vector<point> left_points(points.begin(), points.begin() + medain);
		vector<point> right_points(points.begin() + medain + 1, points.end());

		new_node->left = build_kd_tree(left_points, depth + 1);
		new_node->right = build_kd_tree(right_points, depth + 1);

		return new_node;

	}
public:
	void build(vector<point> points) {
		root = build_kd_tree(points, 0);
	}

	/////////////////////////////////////////////////////////////////////

private:

	bool help_is_exist(node * root, point p1, int depth) {

		if (root == NULL) {
			return false;
		}

		if (p1.get_x() == root->p.get_x() && p1.get_y() == root->p.get_y()) {
			return true;
		}

		/// x->0   y->1
		int axis = depth % 2;
		if (axis == 0) {
			if (p1.get_x() >= root->p.get_x())
				return help_is_exist(root->right, p1, depth + 1);
			else
				return help_is_exist(root->left, p1, depth + 1);
		}
		else {
			if (p1.get_y() >= root->p.get_y())
				return help_is_exist(root->right, p1, depth + 1);
			else
				return help_is_exist(root->left, p1, depth + 1);
		}

	}

public:
	bool is_exist(point p1) {
		return help_is_exist(root, p1, 0);
	}

	///////////////////////////////////////////////////////////////////////

private:

	bool help_is_main_branch(node * root, point p1, int depth) {

		if (root == NULL) {
			return false;
		}

		if (p1.get_x() == root->p.get_x() && p1.get_y() == root->p.get_y()) {

			return root->p.check_main_branch();

		}

		/// x->0   y->1
		int axis = depth % 2;
		if (axis == 0) {
			if (p1.get_x() >= root->p.get_x())
				return help_is_main_branch(root->right, p1, depth + 1);
			else
				return help_is_main_branch(root->left, p1, depth + 1);
		}
		else {
			if (p1.get_y() >= root->p.get_y())
				return help_is_main_branch(root->right, p1, depth + 1);
			else
				return help_is_main_branch(root->left, p1, depth + 1);
		}

	}

public:
	bool is_main_branch(point p1) {
		return help_is_main_branch(root, p1, 0);
	}

	///////////////////////////////////////////////////////////////////////


private:
	void help_rectangle_search(int x1, int x2, int y1, int y2, node * root, vector<point> & empty, int depth) {

		if (root != NULL) {

			if (root->p.get_x() >= x1 && root->p.get_x() <= x2 && root->p.get_y() >= y1 && root->p.get_y() <= y2) {
				empty.push_back(root->p);
			}

			help_rectangle_search(x1, x2, y1, y2, root->left, empty, depth + 1);
			help_rectangle_search(x1, x2, y1, y2, root->right, empty, depth + 1);
		}

	}

public:

	void rectangle_search(int x1, int x2, int y1, int y2) {
		vector<point> empty;
		help_rectangle_search(x1, x2, y1, y2, root, empty, 0);

		Color(5);
		for (int i = 0; i < empty.size(); ++i) {
			cout << "\n";
			cout << "_" << i + 1 << " name:" << empty[i].get_name() <<
				"(x:" << empty[i].get_x() << ",y:" << empty[i].get_y() << ")" << endl;
		}
		Color(7);
	}

	///////////////////////////////////////////////////////////////////////

private:
	node* help_find_nearest_neighber(node * curr, point target, node * best, int depth) {

		if (curr == nullptr) {
			return best;
		}

		if (best == nullptr || distance(best->p, target) > distance(curr->p, target)) {
			best = curr;
		}

		node* next_branch;
		node* other_branch;

		int axis = depth % 2;

		if (axis == 0) {
			if (target.get_x() <= curr->p.get_x()) {
				next_branch = curr->left;
				other_branch = curr->right;
			}
			else {
				next_branch = curr->right;
				other_branch = curr->left;
			}
		}
		else {
			if (target.get_y() <= curr->p.get_y()) {
				next_branch = curr->left;
				other_branch = curr->right;
			}
			else {
				next_branch = curr->right;
				other_branch = curr->left;
			}
		}

		best = help_find_nearest_neighber(next_branch, target, best, depth + 1);

		if (should_check_other_branch(target, curr, best, depth)) {
			best = help_find_nearest_neighber(other_branch, target, best, depth + 1);
		}

		return best;

	}

	// we work whit power of two number and avoid to sqrt
	double distance(point a1, point a2) {
		double result = pow(a1.get_x() - a2.get_x(), 2) + pow(a1.get_y() - a2.get_y(), 2);
		return result;
	}

	bool should_check_other_branch(point target, node * curr, node * best, int depth) {

		double dist = distance(curr->p, target);

		if (depth % 2 == 0) {//x
			return (pow(curr->p.get_x() - target.get_x(), 2) < dist);
		}
		else {
			//y
			return (pow(curr->p.get_y() - target.get_y(), 2) < dist);
		}

	}

public:
	node& find_nearest_neighbor(point target) {
		return *(help_find_nearest_neighber(root, target, NULL, 0));
	}

	//////////////////////////////////////////////////////////////////////

private:
	void help_find_point_in_range(node * node, point target, int radius, int depth, vector<point> & points) {
		if (node == NULL)
			return;

		if (node->p.get_x() >= target.get_x() - radius && node->p.get_x() <= target.get_x() + radius
			&& node->p.get_y() >= target.get_y() - radius &&
			node->p.get_y() <= target.get_y() + radius) {

			double dist = sqrt(pow(node->p.get_x() - target.get_x(), 2) + pow(node->p.get_y() - target.get_y(), 2));

			if (dist <= radius) {
				points.push_back(node->p);
			}

		}

		int axis = depth % 2;

		if (axis == 0) {
			if (target.get_x() - radius < node->p.get_x()) {
				help_find_point_in_range(node->left, target, radius, depth + 1, points);
			}
			if (target.get_x() + radius >= node->p.get_x()) {
				help_find_point_in_range(node->right, target, radius, depth + 1, points);
			}
		}
		else {
			if (target.get_y() - radius < node->p.get_y()) {
				help_find_point_in_range(node->left, target, radius, depth + 1, points);
			}
			if (target.get_y() + radius >= node->p.get_y()) {
				help_find_point_in_range(node->right, target, radius, depth + 1, points);
			}
		}
	}

public:
	vector<point> find_points_in_range(point target, int radius) {
		vector<point> points;
		help_find_point_in_range(root, target, radius, 0, points);
		return points;
	}

	//////////////////////////////////////////////////////////////////////

	void insert(point p1, int depth) {

		node* tmp = root;
		node* save_tmp = root;

		while (tmp != NULL) {

			save_tmp = tmp;

			int axis = depth % 2;
			if (axis == 0) {
				if (p1.get_x() >= tmp->p.get_x()) {
					tmp = tmp->right;
				}
				else {
					tmp = tmp->left;
				}
			}
			else {
				if (p1.get_y() >= tmp->p.get_y()) {
					tmp = tmp->right;
				}
				else {
					tmp = tmp->left;
				}
			}
			++depth;
		}
		--depth;

		if (save_tmp == NULL)
			root = new node(p1);
		else {

			if (depth % 2 == 0) {
				if (save_tmp->p.get_x() <= p1.get_x()) {
					save_tmp->right = new node(p1);
				}
				else {
					save_tmp->left = new node(p1);
				}
			}
			else {
				if (save_tmp->p.get_y() <= p1.get_y()) {
					save_tmp->right = new node(p1);
				}
				else {
					save_tmp->left = new node(p1);
				}
			}
		}

	}

	//////////////////////////////////////////////////////////////////////
private:
	void max_height(node * root, int h) {

		if (root != NULL) {

			if (max < h)
				max = h;

			max_height(root->right, h + 1);
			max_height(root->left, h + 1);

		}
	}

	bool help_check_balance(node * x) {
		if (x != NULL) {
			max_height(x->right, 0);//root
			int r_h = max; max = 0;
			max_height(x->left, 0);//root
			int l_h = max; max = 0;

			return (abs(r_h - l_h) <= 1) && help_check_balance(x->right) && help_check_balance(x->left);

		}
	}

public:

	bool check_balance() {
		return help_check_balance(root);
	}

	//////////////////////////////////////////////////////////////////////

private:
	node* delete_node(node * root, point p1, int depth) {

		if (root == NULL) {
			return NULL;
		}

		int axis = depth % 2;

		if (root->p.get_x() == p1.get_x() && root->p.get_y() == p1.get_y()) {
			if (root->right != NULL) {
				node* min = help_find_min(root->right, depth);
				root->p = min->p;
				root->right = delete_node(root->right, min->p, depth + 1);
			}
			else if (root->left != NULL) {
				node* min = help_find_min(root->left, depth);
				root->p = min->p;
				root->right = delete_node(root->left, min->p, depth + 1);
				root->left = NULL;
			}
			else {
				delete root;
				return NULL;
			}
		}
		else {
			if (axis == 0) {
				if (p1.get_x() < root->p.get_x()) {
					root->left = delete_node(root->left, p1, depth + 1);
				}
				else {
					root->right = delete_node(root->right, p1, depth + 1);
				}
			}
			else {
				if (p1.get_y() < root->p.get_y()) {
					root->left = delete_node(root->left, p1, depth + 1);
				}
				else {
					root->right = delete_node(root->right, p1, depth + 1);
				}
			}
		}

		return root;
	}

	node* help_find_min(node * root, int depth) {

		if (root == NULL) {
			return NULL;
		}

		int axis = depth % 2;

		if (axis == 0) {
			if (root->left == NULL) {
				return root;
			}
			else {
				return help_find_min(root->left, depth + 1);
			}
		}
		else {
			if (root->left == NULL) {
				return root;
			}
			else {
				return help_find_min(root->left, depth + 1);
			}
		}
	}

	node* find_min() {
		return help_find_min(root, 0);
	}

public:
	void delet(point pt) {
		root = delete_node(root, pt, 0);
	}

	///////////////////////////////////////////////////////////////////////
private:
	void help_get_points(vector<point> & p1, node * root) {

		if (root != NULL) {
			p1.push_back(root->p);

			help_get_points(p1, root->right);

			help_get_points(p1, root->left);
		}

	}

public:
	void get_point(vector<point> & p1) {
		help_get_points(p1, root);
	}

	point search(point p1) {

		node* tmp = root;

		int depth = 0;
		while (tmp != NULL) {

			if (tmp->p.get_x() == p1.get_x() && tmp->p.get_y() == p1.get_y()) {
				return tmp->p;
			}

			if (depth % 2 == 0) {
				if (p1.get_x() >= root->p.get_x())
					tmp = tmp->right;
				else
					tmp = tmp->left;
			}
			else {
				if (p1.get_y() >= root->p.get_y())
					tmp = tmp->right;
				else
					tmp = tmp->left;
			}

			++depth;
		}
	}
};

