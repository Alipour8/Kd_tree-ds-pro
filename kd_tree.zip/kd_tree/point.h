#pragma once
#include <string>
using namespace std;

class point {
private:
	int x;
	int y;

	///The name of the pizzeria
	string name;
	///to check is main branch or not?
	bool is_main_branch;
	string main_branch_name;

public:

	point(int _x, int _y, string _name, bool main_br, string name_br) :x(_x), y(_y), name(_name),
		is_main_branch(main_br), main_branch_name(name_br) {};

	int get_x() { return x; };
	int get_y() { return y; };

	string get_name() { return name; };
	string get_main_branch_name() { return main_branch_name; };

	bool check_main_branch() { return is_main_branch; };

};