#pragma warning (disable:4996)
#include "point.h"
#include "kd_tree.h"
#include "hash.h"
#include "color.h"
#include <sstream>


class record {
private:
	vector<string> command;
	vector<string> input;
public:

	void add_command(string s1) {
		command.push_back(s1);
	}

	void add_input(string s1) {
		input.push_back(s1);
	}

	vector<string> get_command() { return command; }
	vector<string> get_input() { return input; }

};

int main(void) {

	record arr[50];

	kd_tree t1;

	/////////////////////////////////////////
	vector<the_neighbourhood> the_neigh;
	/////////////////////////////////////////
	vector<point> all_points;
	/////////////////////////////////////////
	vector<string> main_branch_name;
	///////////// H A S H ///////////////////
	neighbor_hash_table n_h_t;
	pizeria_hash_table p_h_t;


	/////////////// C O N S O L E ///////////


	int time = 0;
	while (true) {



		string line;
		getline(cin, line);


		for (int i = 0; i < line.length(); ++i) {

			// find command
			string command;
			while (line[i] != ' ') {
				command += line[i];
				++i;
			}

			// find input of each command
			string input;
			i += 2;
			while (line[i] != ']') {
				input += line[i];
				++i;
			}
			i += 4;

			arr[time].add_command(command);
			arr[time].add_input(input);

			// -- Add neighborhood -- // 
			if (command == "Add-N") {
				int x1, x2, y1, y2;
				string name;

				istringstream some_stream(input);
				some_stream >> x1 >> x2 >> y1 >> y2 >> name;

				//add to our vector
				the_neigh.push_back(the_neighbourhood(x1, x2, y1, y2, name));

				//add to our hash table
				n_h_t.add_to_hash_table(the_neighbourhood(x1, x2, y1, y2, name));

			}

			// --Adding the main pizzeria(main branch) -- //
			else if (command == "Add-P") {
				int x1, x2;
				string name;

				istringstream some_stream(input);
				some_stream >> x1 >> x2 >> name;

				point p1 = point(x1, x2, name, 1, name);
				if (t1.is_exist(p1)) {

					Color(4);
					cout << "\n__EROR:(" << x1 << "," << x2 << ") this position already exist \n\n";
					Color(7);

				}
				else {
					t1.insert(p1, 0);
					//add to hash table
					p_h_t.add_to_hash_table(p1);

					main_branch_name.push_back(p1.get_main_branch_name());

					if (!t1.check_balance()) {
						t1.get_point(all_points);
						t1.build(all_points);
						all_points.clear();
					}
				}
			}

			// --Adding a pizzeria branch -- //
			else if (command == "Add-Br") {

				int x1, x2;
				string name;
				string main_name;

				istringstream some_stream(input);
				some_stream >> x1 >> x2 >> name >> main_name;


				point p1(x1, x2, name, 0, main_name);

				if (t1.is_exist(p1)) {

					Color(4);
					cout << "\n__EROR:(" << x1 << "," << x2 << ") this position already exist \n\n";
					Color(7);

				}
				else {
					t1.insert(p1, 0);
					//add to hash table
					p_h_t.add_to_hash_table(p1);

					if (!t1.check_balance()) {
						t1.get_point(all_points);
						t1.build(all_points);
						all_points.clear();
					}
				}

			}

			// --Diliting a pizzeria branch -- //
			else if (command == "Del-Br") {
				int x1, x2;

				istringstream some_stream(input);
				some_stream >> x1 >> x2;

				point p1(x1, x2, "", 0, "");

				if (t1.is_exist(p1)) {

					if (t1.is_main_branch(p1)) {
						Color(4);
						cout << "\n__EROR: We cant remove main_branch \n\n";
						Color(7);
					}
					else {

						point p2 = t1.search(point(x1, x2, "", 0, ""));
						p_h_t.delet_pizeria(p2);

						t1.delet(p1);
						if (!t1.check_balance()) {
							t1.get_point(all_points);
							t1.build(all_points);
							all_points.clear();
						}
					}

				}
				else {
					Color(4);
					cout << "\n__EROR:(" << x1 << "," << x2 << ") this position not exist \n\n";
					Color(7);
				}

			}

			// -- List of all pizzerias in a neighborhood -- //
			else if (command == "List-P") {
				string name;

				istringstream some_stream(input);
				some_stream >> name;

				///// find in hash table
				the_neighbourhood b1 = n_h_t.find(name);


				t1.rectangle_search(b1.get_x1(), b1.get_x2(), b1.get_y1(), b1.get_y2());

			}

			// -- Coordinates of all branches of a pizzeria -- //
			else if (command == "List-Brs") {
				string name;

				istringstream some_stream(input);
				some_stream >> name;

				Color(6);
				p_h_t.print(name);
				Color(7);

			}

			// -- The nearest pizzeria -- //
			else if (command == "Near-P") {
				int x1, x2;

				istringstream some_stream(input);
				some_stream >> x1 >> x2;

				point p1(x1, x2, "", 0, "");
				node res = t1.find_nearest_neighbor(p1);

				Color(5);
				cout << "_name:" << res.get_point().get_name() <<
					" _x:" << res.get_point().get_x() <<
					" _y:" << res.get_point().get_y() << endl;
				Color(7);


			}

			// -- The nearest pizzeria branch --//
			else if (command == "Near-Br") {
				int x1, x2;
				string name;

				istringstream some_stream(input);
				some_stream >> x1 >> x2 >> name;

				point p1(x1, x2, "", 0, "");
				p_h_t.find_nearest_branch(p1, name);

			}

			// -- All available pizzerias -- //
			else if (command == "Avail-P") {
				int R, x1, x2;

				istringstream some_stream(input);
				some_stream >> R >> x1 >> x2;

				vector<point> tmp;
				point p1(x1, x2, " ", 0, " ");
				tmp = t1.find_points_in_range(p1, R);

				Color(5);
				for (int i = 0; i < tmp.size(); ++i) {
					cout << "\n";
					cout << "_" << i + 1 << " name:" << tmp[i].get_name() <<
						"(x:" << tmp[i].get_x() << ",y:" << tmp[i].get_y() << ")\n" << endl;
				}
				Color(7);

			}

			// -- The most branched pizzeria -- //
			else if (command == "Most-Brs") {
				p_h_t.Most_brs(main_branch_name);
			}

			// --  U N D O  -- //
			else if (command == "Undo") {
				int p;

				istringstream some_stream(input);
				some_stream >> p;


				/////////////////////////////////////////
				vector<the_neighbourhood> undo_the_neigh;
				/////////////////////////////////////////
				vector<point> undo_all_points;
				/////////////////////////////////////////
				vector<string> undo_main_branch_name;
				///////////// H A S H ///////////////////
				neighbor_hash_table undo_n_h_t;
				pizeria_hash_table undo_p_h_t;

				/// Build befor a time you want 
				kd_tree tmp;
				for (int i = 0; i < p; ++i) {

					vector<string> Command = arr[i].get_command();
					vector<string> Input = arr[i].get_input();

					for (int j = 0; j < Command.size(); ++j) {

						string main_command = Command[j];
						string main_input = Input[j];

						// -- Add neighborhood -- // 
						if (main_command == "Add-N") {
							int x1, x2, y1, y2;
							string name;

							istringstream some_stream(main_input);
							some_stream >> x1 >> x2 >> y1 >> y2 >> name;

							//add to our vector
							undo_the_neigh.push_back(the_neighbourhood(x1, x2, y1, y2, name));

							//add to our hash table
							undo_n_h_t.add_to_hash_table(the_neighbourhood(x1, x2, y1, y2, name));

						}

						// --Adding the main pizzeria(main branch) -- //
						else if (main_command == "Add-P") {
							int x1, x2;
							string name;

							istringstream some_stream(main_input);
							some_stream >> x1 >> x2 >> name;

							point p1 = point(x1, x2, name, 1, name);
							if (tmp.is_exist(p1)) {

								Color(4);
								cout << "\n__EROR:(" << x1 << "," << x2 << ") this position already exist \n\n";
								Color(7);

							}
							else {
								tmp.insert(p1, 0);
								//add to hash table
								undo_p_h_t.add_to_hash_table(p1);

								undo_main_branch_name.push_back(p1.get_main_branch_name());

								if (!tmp.check_balance()) {
									tmp.get_point(undo_all_points);
									tmp.build(undo_all_points);
									undo_all_points.clear();
								}
							}
						}

						// --Adding a pizzeria branch -- //
						else if (main_command == "Add-Br") {

							int x1, x2;
							string name;
							string main_name;

							istringstream some_stream(main_input);
							some_stream >> x1 >> x2 >> name >> main_name;


							point p1(x1, x2, name, 0, main_name);

							if (tmp.is_exist(p1)) {

								Color(4);
								cout << "\n__EROR:(" << x1 << "," << x2 << ") this position already exist \n\n";
								Color(7);

							}
							else {
								tmp.insert(p1, 0);
								//add to hash table
								undo_p_h_t.add_to_hash_table(p1);

								if (!tmp.check_balance()) {
									tmp.get_point(undo_all_points);
									tmp.build(undo_all_points);
									undo_all_points.clear();
								}
							}

						}

						// --Diliting a pizzeria branch -- //
						else if (main_command == "Del-Br") {
							int x1, x2;

							istringstream some_stream(main_input);
							some_stream >> x1 >> x2;

							point p1(x1, x2, "", 0, "");

							if (tmp.is_exist(p1)) {

								if (tmp.is_main_branch(p1)) {
									Color(4);
									cout << "\n__EROR: We cant remove main_branch \n\n";
									Color(7);
								}
								else {

									point p2 = tmp.search(point(x1, x2, "", 0, ""));
									undo_p_h_t.delet_pizeria(p2);

									tmp.delet(p1);
									if (!tmp.check_balance()) {
										tmp.get_point(undo_all_points);
										tmp.build(undo_all_points);
										undo_all_points.clear();
									}
								}

							}
							else {
								Color(4);
								cout << "\n__EROR:(" << x1 << "," << x2 << ") this position not exist \n\n";
								Color(7);
							}

						}

						// -- List of all pizzerias in a neighborhood -- //
						else if (main_command == "List-P") {
							string name;

							istringstream some_stream(main_input);
							some_stream >> name;

							///// find in hash table
							the_neighbourhood b1 = undo_n_h_t.find(name);


							tmp.rectangle_search(b1.get_x1(), b1.get_x2(), b1.get_y1(), b1.get_y2());

						}

						// -- Coordinates of all branches of a pizzeria -- //
						else if (main_command == "List-Brs") {
							string name;

							istringstream some_stream(main_input);
							some_stream >> name;

							Color(6);
							undo_p_h_t.print(name);
							Color(7);

						}

						// -- The nearest pizzeria -- //
						else if (main_command == "Near-P") {
							int x1, x2;

							istringstream some_stream(main_input);
							some_stream >> x1 >> x2;

							point p1(x1, x2, "", 0, "");
							node res = tmp.find_nearest_neighbor(p1);

							Color(5);
							cout << "_name:" << res.get_point().get_name() <<
								" _x:" << res.get_point().get_x() <<
								" _y:" << res.get_point().get_y() << endl;
							Color(7);


						}

						// -- The nearest pizzeria branch --//
						else if (main_command == "Near-Br") {
							int x1, x2;
							string name;

							istringstream some_stream(main_input);
							some_stream >> x1 >> x2 >> name;

							point p1(x1, x2, "", 0, "");
							undo_p_h_t.find_nearest_branch(p1, name);

						}

						// -- All available pizzerias -- //
						else if (main_command == "Avail-P") {
							int R, x1, x2;

							istringstream some_stream(main_input);
							some_stream >> R >> x1 >> x2;

							vector<point> tmp1;
							point p1(x1, x2, " ", 0, " ");
							tmp1 = tmp.find_points_in_range(p1, R);

							Color(5);
							for (int i = 0; i < tmp1.size(); ++i) {
								cout << "\n";
								cout << "_" << i + 1 << " name:" << tmp1[i].get_name() <<
									"(x:" << tmp1[i].get_x() << ",y:" << tmp1[i].get_y() << ")\n" << endl;
							}
							Color(7);

						}

						// -- The most branched pizzeria -- //
						else if (main_command == "Most-Brs") {
							undo_p_h_t.Most_brs(main_branch_name);
						}
					}


				}

				Color(10);
				cout << "\n\n which command you want to move to it on time:" << p << endl << endl;
				vector<string>s1 = arr[p].get_command();
				for (int i = 0; i < s1.size(); ++i) {
					cout << "_" << i + 1 << "_" << s1[i] << endl;
				}
				Color(7);
				cout << "\n__ command:";
				int move;
				cin >> move;

				vector<string> Command = arr[p].get_command();
				vector<string> Input = arr[p].get_input();

				for (int j = 0; j < move; ++j) {

						string main_command = Command[j];
						string main_input = Input[j];

						// -- Add neighborhood -- // 
						if (main_command == "Add-N") {
							int x1, x2, y1, y2;
							string name;

							istringstream some_stream(main_input);
							some_stream >> x1 >> x2 >> y1 >> y2 >> name;

							//add to our vector
							undo_the_neigh.push_back(the_neighbourhood(x1, x2, y1, y2, name));

							//add to our hash table
							undo_n_h_t.add_to_hash_table(the_neighbourhood(x1, x2, y1, y2, name));

						}

						// --Adding the main pizzeria(main branch) -- //
						else if (main_command == "Add-P") {
							int x1, x2;
							string name;

							istringstream some_stream(main_input);
							some_stream >> x1 >> x2 >> name;

							point p1 = point(x1, x2, name, 1, name);
							if (tmp.is_exist(p1)) {

								Color(4);
								cout << "\n__EROR:(" << x1 << "," << x2 << ") this position already exist \n\n";
								Color(7);

							}
							else {
								tmp.insert(p1, 0);
								//add to hash table
								undo_p_h_t.add_to_hash_table(p1);

								undo_main_branch_name.push_back(p1.get_main_branch_name());

								if (!tmp.check_balance()) {
									tmp.get_point(undo_all_points);
									tmp.build(undo_all_points);
									undo_all_points.clear();
								}
							}
						}

						// --Adding a pizzeria branch -- //
						else if (main_command == "Add-Br") {

							int x1, x2;
							string name;
							string main_name;

							istringstream some_stream(main_input);
							some_stream >> x1 >> x2 >> name >> main_name;


							point p1(x1, x2, name, 0, main_name);

							if (tmp.is_exist(p1)) {

								Color(4);
								cout << "\n__EROR:(" << x1 << "," << x2 << ") this position already exist \n\n";
								Color(7);

							}
							else {
								tmp.insert(p1, 0);
								//add to hash table
								undo_p_h_t.add_to_hash_table(p1);

								if (!tmp.check_balance()) {
									tmp.get_point(undo_all_points);
									tmp.build(undo_all_points);
									undo_all_points.clear();
								}
							}

						}

						// --Diliting a pizzeria branch -- //
						else if (main_command == "Del-Br") {
							int x1, x2;

							istringstream some_stream(main_input);
							some_stream >> x1 >> x2;

							point p1(x1, x2, "", 0, "");

							if (tmp.is_exist(p1)) {

								if (tmp.is_main_branch(p1)) {
									Color(4);
									cout << "\n__EROR: We cant remove main_branch \n\n";
									Color(7);
								}
								else {

									point p2 = tmp.search(point(x1, x2, "", 0, ""));
									undo_p_h_t.delet_pizeria(p2);

									tmp.delet(p1);
									if (!tmp.check_balance()) {
										tmp.get_point(undo_all_points);
										tmp.build(undo_all_points);
										undo_all_points.clear();
									}
								}

							}
							else {
								Color(4);
								cout << "\n__EROR:(" << x1 << "," << x2 << ") this position not exist \n\n";
								Color(7);
							}

						}

						// -- List of all pizzerias in a neighborhood -- //
						else if (main_command == "List-P") {
							string name;

							istringstream some_stream(main_input);
							some_stream >> name;

							///// find in hash table
							the_neighbourhood b1 = undo_n_h_t.find(name);


							tmp.rectangle_search(b1.get_x1(), b1.get_x2(), b1.get_y1(), b1.get_y2());

						}

						// -- Coordinates of all branches of a pizzeria -- //
						else if (main_command == "List-Brs") {
							string name;

							istringstream some_stream(main_input);
							some_stream >> name;

							Color(6);
							undo_p_h_t.print(name);
							Color(7);

						}

						// -- The nearest pizzeria -- //
						else if (main_command == "Near-P") {
							int x1, x2;

							istringstream some_stream(main_input);
							some_stream >> x1 >> x2;

							point p1(x1, x2, "", 0, "");
							node res = tmp.find_nearest_neighbor(p1);

							Color(5);
							cout << "_name:" << res.get_point().get_name() <<
								" _x:" << res.get_point().get_x() <<
								" _y:" << res.get_point().get_y() << endl;
							Color(7);


						}

						// -- The nearest pizzeria branch --//
						else if (main_command == "Near-Br") {
							int x1, x2;
							string name;

							istringstream some_stream(main_input);
							some_stream >> x1 >> x2 >> name;

							point p1(x1, x2, "", 0, "");
							undo_p_h_t.find_nearest_branch(p1, name);

						}

						// -- All available pizzerias -- //
						else if (main_command == "Avail-P") {
							int R, x1, x2;

							istringstream some_stream(main_input);
							some_stream >> R >> x1 >> x2;

							vector<point> tmp1;
							point p1(x1, x2, " ", 0, " ");
							tmp1 = tmp.find_points_in_range(p1, R);

							Color(5);
							for (int i = 0; i < tmp1.size(); ++i) {
								cout << "\n";
								cout << "_" << i + 1 << " name:" << tmp1[i].get_name() <<
									"(x:" << tmp1[i].get_x() << ",y:" << tmp1[i].get_y() << ")\n" << endl;
							}
							Color(7);

						}

						// -- The most branched pizzeria -- //
						else if (main_command == "Most-Brs") {
							undo_p_h_t.Most_brs(main_branch_name);
						}
					}

				while (1) {

					//string line;
					string command;
					cin >> command;

					// -- List of all pizzerias in a neighborhood -- //
					if (command == "List-P") {
						string name;

						cout << "please enter a name:";
						cin >> name;

						///// find in hash table
						the_neighbourhood b1 = undo_n_h_t.find(name);


						tmp.rectangle_search(b1.get_x1(), b1.get_x2(), b1.get_y1(), b1.get_y2());

					}

					// -- Coordinates of all branches of a pizzeria -- //
					else if (command == "List-Brs") {
						
						cout << "please enter name: ";
						string name;
						cin>> name;

						Color(6);
						undo_p_h_t.print(name);
						Color(7);

					}

					// -- The nearest pizzeria -- //
					else if (command == "Near-P") {
						int x1, x2;

						cout << "please enter x1: x2: ";
						cin >> x1 >> x2;

						point p1(x1, x2, "", 0, "");
						node res = tmp.find_nearest_neighbor(p1);

						Color(5);
						cout << "_name:" << res.get_point().get_name() <<
							" _x:" << res.get_point().get_x() <<
							" _y:" << res.get_point().get_y() << endl;
						Color(7);


					}

					// -- The nearest pizzeria branch --//
					else if (command == "Near-Br") {
						int x1, x2;
						string name;

						cout << "please enter x1: x2: name:";
						cin >> x1 >> x2 >> name;

						point p1(x1, x2, "", 0, "");
						undo_p_h_t.find_nearest_branch(p1, name);

					}

					// -- All available pizzerias -- //
					else if (command == "Avail-P") {
						int R, x1, x2;

						cout << "_please enter R X1 X2 :";
						cin >> R >> x1 >> x2;

						vector<point> tmp2;
						point p1(x1, x2, " ", 0, " ");
						tmp2 = tmp.find_points_in_range(p1, R);

						Color(5);
						for (int i = 0; i < tmp2.size(); ++i) {
							cout << "\n";
							cout << "_" << i + 1 << " name:" << tmp2[i].get_name() <<
								"(x:" << tmp2[i].get_x() << ",y:" << tmp2[i].get_y() << ")\n" << endl;
						}
						Color(7);

					}

					// -- The most branched pizzeria -- //
					else if (command == "Most-Brs") {
						undo_p_h_t.Most_brs(undo_main_branch_name);
					}


					cout << "\n__Do you want back to main branch ???" << endl;
					string resu;
					cin >> resu;
					if (resu == "yes")
						break;
				}	
			}
		}
		++time;
	}

	return 0;
}